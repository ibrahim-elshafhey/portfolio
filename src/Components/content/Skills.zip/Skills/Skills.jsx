import React from 'react'
import Cards from './Cards/Cards'
import './Skills.css'

const Skills = () => {
    let {isScrolled,setScrolled} = false


  return (
   <>
   <Cards />
   
   </>
  )
}

export default Skills
