import React from 'react'
import './Cards.css'

const Cards = () => {
    const cards = [
  { title: 'JavaScript', level: 80, description: 'Proficient in JavaScript programming' },
  { title: 'React', level: 75, description: 'Experienced with React framework' },
  { title: 'Node.js', level: 70, description: 'Skilled in server-side development with Node.js' },
  { title: 'HTML/CSS', level: 90, description: 'Strong understanding of HTML and CSS for web development' },
  { title: 'Python', level: 65, description: 'Familiar with Python programming and scripting' },
  { title: 'SQL', level: 60, description: 'Knowledgeable in database management and SQL queries' }
]
  return (
    <div className="skills-container">
      {cards.map((card) => (
        <div key={card.title} className="skill-card">
          <h3>{card.title}</h3>
          <div className="skill-level">
            <div style={{ width: `${card.level}%` }} />
          </div>
          <p>{card.description}</p>
        </div>
      ))}
    </div>
  )
}

export default Cards
